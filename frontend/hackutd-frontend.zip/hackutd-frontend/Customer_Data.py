# customer_data.py
product_catalog = [
    {
        "name": "High-Speed Internet Pro",
        "features": "1 Gbps, unlimited data",
        "price": "$89.99/month"
    },
    # Add more products as needed
]

customer_profiles = [
    {
        "acct_name": "Jane Doe",
        "extenders": 2,
        "wireless_clients_count": 8,
        "wired_clients_count": 2,
        "network_speed": "100 Mbps",
        "city": "Los Angeles",
        "state": "CA",
        "whole_home_wifi": True,
        "wifi_security": True,
        "wifi_security_plus": False
    },
    # Add more profiles as needed
]
